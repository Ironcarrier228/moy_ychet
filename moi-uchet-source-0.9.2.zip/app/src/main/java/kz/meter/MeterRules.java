package kz.meter;
import org.json.*;import java.time.*;
/** Shared non-overridable baseline rules for native entry and XLSX import. */
public final class MeterRules {
 public static LocalDate date(String value)throws Exception {
  if(value==null||!value.matches("\\d{4}-\\d{2}-\\d{2}"))throw new Exception("Укажите начальную дату прибора");
  try{return LocalDate.parse(value);}catch(Exception e){throw new Exception("Некорректная начальная дата прибора");}
 }
 public static void check(JSONObject meter,String readingDate,long value)throws Exception {
  LocalDate initial=date(meter.optString("initialDate"));LocalDate reading=LocalDate.parse(readingDate);
  if(reading.isBefore(initial))throw new Exception("Дата показания не может быть раньше начальной даты прибора: "+initial);
  long baseline=meter.getLong("initial");if(value<baseline)throw new Exception("Показание не может быть меньше начального значения прибора: "+baseline);
 }
 public static void checkPrevious(JSONObject meter,long previous)throws Exception {if(previous<meter.getLong("initial"))throw new Exception("Предыдущее показание меньше начального значения прибора: "+meter.getLong("initial"));}
 public static JSONObject prepare(JSONObject draft,JSONObject old,JSONArray readings)throws Exception {
  JSONObject out=new JSONObject(draft.toString());out.put("initial",Validation.normalize(out.optString("initial","")));LocalDate start=date(out.optString("initialDate"));if(start.isAfter(LocalDate.now()))throw new Exception("Начальная дата не может быть в будущем");
  if(out.optString("type").trim().isEmpty())throw new Exception("Укажите тип прибора");if(out.optString("number").trim().isEmpty())throw new Exception("Укажите номер прибора");out.put("number",out.getString("number").trim());out.put("active",out.optBoolean("active",true));
  if(old.length()>0&&!old.getString("subscriber").equals(out.optString("subscriber")))throw new Exception("Нельзя переносить прибор другому абоненту");
  boolean hasHistory=false;for(int i=0;i<readings.length();i++){JSONObject r=readings.getJSONObject(i);if(!r.optString("meter").equals(out.getString("id")))continue;hasHistory=true;
   try{check(out,r.getString("date"),r.getLong("value"));checkPrevious(out,r.getLong("previous"));}catch(Exception e){throw new Exception("Начальные данные противоречат сохранённой записи от "+r.optString("date")+": "+e.getMessage()+". История не изменена.");}
  }
  if(hasHistory&&old.length()>0&&(!old.getString("type").equals(out.getString("type"))||!old.getString("number").equals(out.getString("number"))))throw new Exception("У прибора есть история. Номер и тип менять нельзя: для замены создайте новый прибор, старый архивируйте.");
  return out;
 }
}
