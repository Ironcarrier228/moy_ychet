package kz.meter;
import java.util.*;import java.util.regex.*;import org.json.*;
/** General text heuristic, not a trained meter detector. No device names or sample values. */
public final class ReadingExtractor {
 private static final String NUMBER="[0-9]+(?:[ \\t\\u00a0\\u202f]+[0-9]+)*(?:[.,][0-9]+)?";
 private static final Pattern STANDALONE=Pattern.compile("^("+NUMBER+")$");
 private static final Pattern LABELLED=Pattern.compile("(?iu)^(?:показани[ея]|показания\\s+сч[её]тчика|reading|meter\\s+reading)\\s*[:=]?\\s*("+NUMBER+")(?:\\s*(?:квт[·•*\\s.]*ч|kw[·•*\\s.\\-]*h|м[³3]|m[³3]))?$");
 private static final Pattern WITH_UNIT=Pattern.compile("(?iu)^("+NUMBER+")\\s*(?:квт[·•*\\s.]*ч|kw[·•*\\s.\\-]*h|м[³3]|m[³3])$");
 private static final Pattern SERIAL_LABEL=Pattern.compile("(?iu)^(?:№|n[º°o]?\\.?|s/?n|serial(?:\\s+(?:number|no\\.?))?|серийный(?:\\s+номер)?|заводской(?:\\s+номер)?|номер(?:\\s+(?:прибора|сч[её]тчика))?|год(?:\\s+(?:выпуска|вып\\.?))?)\\s*[:=]?$");
 public static JSONObject extract(String text)throws Exception {
 List<JSONObject> choices=new ArrayList<>();Set<String> seen=new HashSet<>();String previous="";int order=0;
 for(String original:text.split("[\\r\\n]+")){String line=original.replace('\u00a0',' ').replace('\u202f',' ').trim();if(line.isEmpty())continue;String token=null;int score=0;Matcher labelled=LABELLED.matcher(line),solo=STANDALONE.matcher(line),unit=WITH_UNIT.matcher(line);
 if(labelled.matches()){token=labelled.group(1);score=100;}else if(solo.matches()&&!SERIAL_LABEL.matcher(previous).matches()){token=solo.group(1);score=80;}else if(unit.matches()){token=unit.group(1);score=90;}
 if(token!=null){try{String normalized=token.replaceAll("\\s", "");long value=Validation.normalize(normalized);String key=String.valueOf(value);JSONObject option=new JSONObject().put("raw",token).put("value",value).put("line",line).put("score",score).put("order",order);
 if(seen.add(key))choices.add(option);else for(int i=0;i<choices.size();i++)if(choices.get(i).getLong("value")==value&&choices.get(i).getInt("score")<score){choices.set(i,option);break;}
 }catch(IllegalArgumentException ignored){}}
 previous=line;order++;
 }
 choices.sort((a,b)->{int c=Integer.compare(b.optInt("score"),a.optInt("score"));return c!=0?c:Integer.compare(a.optInt("order"),b.optInt("order"));});JSONArray array=new JSONArray();for(int i=0;i<Math.min(40,choices.size());i++){JSONObject c=new JSONObject(choices.get(i).toString());c.remove("score");c.remove("order");array.put(c);}
 JSONObject result=new JSONObject().put("candidates",array).put("manualRequired",true).put("ambiguous",choices.size()>1);
 if(!choices.isEmpty())result.put("suggested",array.getJSONObject(0));return result;
 }
}
