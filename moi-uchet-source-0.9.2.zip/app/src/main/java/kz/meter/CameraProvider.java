package kz.meter;
import android.content.*;import android.database.*;import android.net.Uri;import android.os.ParcelFileDescriptor;import java.io.*;
/** Only a temporary capture file is exposed, with a URI permission granted to the camera. */
public class CameraProvider extends ContentProvider {
 public boolean onCreate(){return true;}
 public String getType(Uri uri){return "image/jpeg";}
 public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {if(!"/capture.jpg".equals(uri.getPath()))throw new FileNotFoundException();return ParcelFileDescriptor.open(new File(getContext().getCacheDir(),"capture.jpg"),ParcelFileDescriptor.parseMode(mode));}
 public Cursor query(Uri uri,String[] p,String s,String[] a,String order){MatrixCursor c=new MatrixCursor(new String[]{"_display_name","_size"});c.addRow(new Object[]{"capture.jpg",new File(getContext().getCacheDir(),"capture.jpg").length()});return c;}
 public Uri insert(Uri uri,ContentValues v){throw new UnsupportedOperationException();}
 public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
 public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
}
