package kz.meter;
import android.app.job.*;import java.util.concurrent.atomic.AtomicBoolean;
public class TelegramReminderJob extends JobService {
 private AtomicBoolean stopped;
 public boolean onStartJob(JobParameters params){final AtomicBoolean flag=new AtomicBoolean(false);stopped=flag;new Thread(()->{Store db=new Store(this);try{new TelegramReminders(this,db).tick(flag);}catch(Exception e){try{db.event("Telegram: фоновая ошибка",e.getMessage()==null?"Ошибка задачи":e.getMessage());}catch(Exception ignored){}}finally{db.close();if(!flag.get())jobFinished(params,false);}}).start();return true;}
 public boolean onStopJob(JobParameters params){if(stopped!=null)stopped.set(true);return true;}
}
