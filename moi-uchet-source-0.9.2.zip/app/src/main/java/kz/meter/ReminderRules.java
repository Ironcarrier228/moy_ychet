package kz.meter;
import java.time.*;import org.json.*;
public final class ReminderRules {
 // Kazakhstan is UTC+5; fixed offset also works with older Android timezone databases.
 public static final ZoneId ZONE=ZoneOffset.ofHours(5);
 public static ZonedDateTime now(){return ZonedDateTime.now(ZONE);}
 public static void validate(JSONObject r)throws Exception{
 String mode=r.optString("mode","monthly");LocalTime.parse(r.optString("time","10:00"));if(!mode.equals("once")&&!mode.equals("monthly"))throw new Exception("Выберите тип напоминания");
 if(mode.equals("once"))LocalDate.parse(r.getString("date"));else{for(String k:new String[]{"start","end","every"})if(r.has(k)){double v=r.getDouble(k);if(Double.isNaN(v)||Double.isInfinite(v)||v!=Math.rint(v))throw new Exception("Дни и интервал должны быть целыми числами");}int start=r.optInt("start",20),end=r.optInt("end",28),every=r.optInt("every",1);if(start<1||end>31||end<start||every<1||every>31)throw new Exception("Дни: от 1 до 31; конец не раньше начала; интервал: 1–31 день");}
 if(r.optString("text").trim().isEmpty()||r.optString("text").length()>3500)throw new Exception("Текст напоминания: от 1 до 3500 символов");
 }
 public static boolean due(JSONObject r,ZonedDateTime now)throws Exception{
 if(!r.optBoolean("enabled"))return false;LocalDate date=now.toLocalDate();if(now.toLocalTime().isBefore(LocalTime.parse(r.optString("time","10:00"))))return false;
 if(r.optString("mode","monthly").equals("once"))return date.toString().equals(r.optString("date"));int d=date.getDayOfMonth(),start=r.optInt("start",20),end=r.optInt("end",28);return d>=start&&d<=end&&(d-start)%r.optInt("every",1)==0;
 }
 public static int activeMeters(String subscriber,JSONObject state)throws Exception{int count=0;JSONArray meters=state.getJSONArray("meters");for(int i=0;i<meters.length();i++){JSONObject m=meters.getJSONObject(i);if(subscriber.equals(m.optString("subscriber"))&&m.optBoolean("active",true))count++;}return count;}
 public static boolean complete(String subscriber,JSONObject state,String month)throws Exception{JSONArray meters=state.getJSONArray("meters"),readings=state.getJSONArray("readings");int required=0;for(int i=0;i<meters.length();i++){JSONObject m=meters.getJSONObject(i);if(!subscriber.equals(m.optString("subscriber"))||!m.optBoolean("active",true))continue;required++;boolean received=false;for(int j=0;j<readings.length();j++){JSONObject r=readings.getJSONObject(j);if(m.getString("id").equals(r.optString("meter"))&&r.optString("date").startsWith(month)){received=true;break;}}if(!received)return false;}return required>0;}
}
