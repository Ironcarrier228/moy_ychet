package kz.meter;
import android.content.*;import android.security.keystore.*;import android.util.Base64;import javax.crypto.*;import javax.crypto.spec.GCMParameterSpec;import java.security.*;
public class Secrets{
 private Context c; public Secrets(Context c){this.c=c;}
 private java.security.Key key()throws Exception{KeyStore s=KeyStore.getInstance("AndroidKeyStore");s.load(null);if(!s.containsAlias("meter-secrets")){KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder("meter-secrets",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());g.generateKey();}return s.getKey("meter-secrets",null);}
 public void set(String name,String value)throws Exception{Cipher x=Cipher.getInstance("AES/GCM/NoPadding");x.init(Cipher.ENCRYPT_MODE,key());String data=Base64.encodeToString(x.getIV(),2)+":"+Base64.encodeToString(x.doFinal(value.getBytes("UTF-8")),2);c.getSharedPreferences("vault",0).edit().putString(name,data).apply();}
 public String get(String name)throws Exception{String d=c.getSharedPreferences("vault",0).getString(name,"");if(d.isEmpty())return "";String[] p=d.split(":");Cipher x=Cipher.getInstance("AES/GCM/NoPadding");x.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(p[0],2)));return new String(x.doFinal(Base64.decode(p[1],2)),"UTF-8");}
}
