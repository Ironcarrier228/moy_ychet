package kz.meter;
import org.json.*;import java.util.*;
/** Active history is a projection. Original readings and cancellation audit stay immutable. */
public final class HistoryView {
 public static JSONArray active(JSONArray originals,JSONArray meters,JSONArray voids)throws Exception {
  Set<String> removed=new HashSet<>();Map<String,String> cut=new HashMap<>();Map<String,Long> initial=new HashMap<>();
  for(int i=0;i<meters.length();i++){JSONObject m=meters.getJSONObject(i);initial.put(m.getString("id"),m.optLong("initial",0));}
  for(int i=0;i<voids.length();i++){JSONObject v=voids.getJSONObject(i);removed.add(v.getString("id"));String meter=v.getString("meter"),date=v.getString("date");if(!cut.containsKey(meter)||date.compareTo(cut.get(meter))<0)cut.put(meter,date);}
  List<JSONObject> rows=new ArrayList<>();for(int i=0;i<originals.length();i++){JSONObject r=originals.getJSONObject(i);if(!removed.contains(r.getString("id")))rows.add(new JSONObject(r.toString()));}
  rows.sort(Comparator.comparing((JSONObject r)->r.optString("date")).thenComparing(r->r.optString("id")));
  Map<String,Long> last=new HashMap<>();JSONArray out=new JSONArray();
  for(JSONObject r:rows){String meter=r.getString("meter");long value=r.getLong("value");if(cut.containsKey(meter)&&r.getString("date").compareTo(cut.get(meter))>=0){long previous=last.containsKey(meter)?last.get(meter):initial.getOrDefault(meter,r.getLong("previous"));long savedPrevious=r.getLong("previous"),savedUsage=r.getLong("usage");if(previous!=savedPrevious||value-previous!=savedUsage){r.put("savedPrevious",savedPrevious).put("savedUsage",savedUsage).put("recalculated",true).put("calculationNote","Расход пересчитан без удалённых записей; исходная запись сохранена в аудите");}r.put("previous",previous).put("usage",value-previous);}last.put(meter,value);out.put(r);}
  return out;
 }
}
