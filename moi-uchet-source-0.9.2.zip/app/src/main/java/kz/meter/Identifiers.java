package kz.meter;
import java.text.Normalizer;import java.util.Locale;import java.math.BigDecimal;
/** Only format differences; punctuation in alphanumeric identifiers remains significant. */
public final class Identifiers {
 public static String compact(String raw){String s=Normalizer.normalize(raw==null?"":raw,Normalizer.Form.NFKC).replaceAll("[\\s\\p{Z}\\u200B\\uFEFF]","");if(s.startsWith("'"))s=s.substring(1);return s;}
 public static String key(String raw){String s=compact(raw);if(s.length()>150)return s; if(s.matches("[0-9]+(?:[.,][0-9]+)?(?:[eE][+]?[0-9]{1,2})?")){try{BigDecimal d=new BigDecimal(s.replace(',','.'));if(d.scale()<=0||d.stripTrailingZeros().scale()<=0){if(d.precision()-d.scale()<=100)return d.toBigIntegerExact().toString();}}catch(Exception ignored){}}return s.toUpperCase(Locale.ROOT);}
 public static boolean matches(String a,String b){return !key(a).isEmpty()&&key(a).equals(key(b));}
 public static String type(String raw){String s=compact(raw).toUpperCase(Locale.ROOT);if(s.equals("ГАЗ")||s.equals("ГАЗОСНАБЖЕНИЕ")||s.equals("GAS"))return "ГАЗ";if(s.equals("ХОЛОДНАЯВОДА")||s.equals("ХОЛОДНОЕВОДОСНАБЖЕНИЕ"))return "ХВС";if(s.equals("ГОРЯЧАЯВОДА")||s.equals("ГОРЯЧЕЕВОДОСНАБЖЕНИЕ"))return "ГВС";if(s.equals("ЭЛЕКТРИЧЕСТВО")||s.equals("ЭЛЕКТРО")||s.equals("ЭЛЕКТРОЭНЕРГИЯ"))return "ЭЛЕКТРОЭНЕРГИЯ";return s;}
 public static String header(String raw){String s=compact(raw).toLowerCase(Locale.ROOT);if(s.startsWith("no"))s="№"+s.substring(2);
 String erc=s.replace('ё','е').replaceAll("[^\\p{L}0-9]", "");
 if(erc.equals("erc")||erc.equals("ercnumber")||erc.equals("numbererc"))return "ЕРЦ";
 erc=erc.replace('e','е').replace('p','р');
 if(erc.equals("ерц")||erc.equals("номерерц")||erc.equals("ерцномер")||erc.equals("ерцno")||erc.equals("noерц")||erc.equals("номерерцастана")||erc.equals("ерцастана")||erc.equals("лсерц")||erc.equals("ерцлс")||erc.equals("лицевойсчетерц")||erc.equals("ерцлицевойсчет")||erc.equals("номерлицевогосчетаерц"))return "ЕРЦ";
 switch(s){case "ерц":case "номерерц":case "№ерц":return "ЕРЦ";case "дата":case "датапоказания":return "Дата";case "типприбора":case "типсчетчика":case "типсчётчика":return "Тип прибора";case "№прибора":case "номерприбора":case "номерсчётчика":case "номерсчетчика":case "№счётчика":case "№счетчика":return "№ прибора";case "предыдущеепоказание":case "предыдущиепоказания":return "Предыдущее показание";case "новоепоказание":case "новыепоказания":return "Новое показание";default:return raw.trim();}}
}
