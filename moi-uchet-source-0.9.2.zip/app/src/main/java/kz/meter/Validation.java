package kz.meter;
public final class Validation {
 public static long normalize(String raw) {
  if(raw==null || raw.contains("-")) throw new IllegalArgumentException("Введите неотрицательное показание");
  String s=raw.replaceAll("\\s", "").split("[.,]",-1)[0].replaceAll("[^0-9]", "");
  if(s.isEmpty()) throw new IllegalArgumentException("На фото не найдено целое показание");
  long v=Long.parseLong(s); if(v>9007199254740991L) throw new IllegalArgumentException("Слишком большое значение");return v;
 }
 public static String warning(long v,long p,long threshold){return v<p?"ВНИМАНИЕ! Новое показание меньше предыдущего. Проверьте правильность распознавания.":v-p>threshold?"Обнаружено необычно большое потребление. Проверьте показание.":"";}
}
