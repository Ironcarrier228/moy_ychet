package kz.meter;
/** SQL shared by installation and v2 -> v3 upgrade. */
public final class HistorySchema {
 public static final String READINGS="CREATE TABLE readings(id TEXT PRIMARY KEY, meter TEXT NOT NULL, date TEXT NOT NULL, value INTEGER NOT NULL CHECK(value>=0), data TEXT NOT NULL)";
 public static final String[] AUDIT={
  "CREATE TABLE reading_voids(id TEXT PRIMARY KEY,data TEXT NOT NULL)",
  "CREATE TRIGGER immutable_voids_update BEFORE UPDATE ON reading_voids BEGIN SELECT RAISE(ABORT,'Immutable cancellation'); END",
  "CREATE TRIGGER immutable_voids_delete BEFORE DELETE ON reading_voids BEGIN SELECT RAISE(ABORT,'Immutable cancellation'); END"
 };
 public static final String[] GUARDS={
  "CREATE INDEX readings_meter_date ON readings(meter,date)",
  "CREATE VIEW active_readings AS SELECT r.* FROM readings r WHERE NOT EXISTS(SELECT 1 FROM reading_voids v WHERE v.id=r.id)",
  "CREATE TRIGGER immutable_readings_update BEFORE UPDATE ON readings BEGIN SELECT RAISE(ABORT,'Immutable reading'); END",
  "CREATE TRIGGER immutable_readings_delete BEFORE DELETE ON readings BEGIN SELECT RAISE(ABORT,'Immutable reading'); END",
  "CREATE TRIGGER unique_active_reading BEFORE INSERT ON readings WHEN EXISTS(SELECT 1 FROM active_readings r WHERE r.meter=NEW.meter AND r.date=NEW.date) BEGIN SELECT RAISE(ABORT,'Reading already exists for date'); END"
 };
 public static final String[] UPGRADE_BEFORE={
  "DROP TRIGGER IF EXISTS immutable_readings_update",
  "DROP TRIGGER IF EXISTS immutable_readings_delete",
  "ALTER TABLE readings RENAME TO readings_legacy"
 };
 public static final String[] UPGRADE_AFTER={
  "INSERT INTO readings(id,meter,date,value,data) SELECT id,meter,date,value,data FROM readings_legacy",
  "DROP TABLE readings_legacy"
 };
}
