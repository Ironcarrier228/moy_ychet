package android.database.sqlite;import android.content.*;import android.database.*;
public abstract class SQLiteOpenHelper {public static SQLiteDatabase seed;private SQLiteDatabase db;private int version;public SQLiteOpenHelper(Context c,String name,Object factory,int version){this.version=version;}public abstract void onCreate(SQLiteDatabase d);public abstract void onUpgrade(SQLiteDatabase d,int old,int target);
 public SQLiteDatabase getWritableDatabase(){if(db==null){db=seed==null?new SQLiteDatabase("jdbc:sqlite::memory:"):seed;seed=null;int old;try(Cursor c=db.rawQuery("PRAGMA user_version",null)){c.moveToFirst();old=(int)c.getLong(0);}if(old!=version){db.beginTransaction();try{if(old==0)onCreate(db);else onUpgrade(db,old,version);db.execSQL("PRAGMA user_version="+version);db.setTransactionSuccessful();}finally{db.endTransaction();}}}return db;}
 public SQLiteDatabase getReadableDatabase(){return getWritableDatabase();}public void close(){if(db!=null)db.close();}
}
