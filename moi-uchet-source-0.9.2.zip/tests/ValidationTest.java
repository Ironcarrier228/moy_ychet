import kz.meter.Validation;
public class ValidationTest {
 public static void main(String[] args){
 String[] raw={"001234.567","001234","1234,5"," 001 234.567 м³","0","000.9","Показание: 001258"};long[] expected={1234,1234,1234,1234,0,0,1258};
 for(int i=0;i<raw.length;i++)if(Validation.normalize(raw[i])!=expected[i])throw new AssertionError(raw[i]);
 for(String s:new String[]{"","abc","-1","999999999999999999999999","9007199254740992"}){boolean failed=false;try{Validation.normalize(s);}catch(Exception e){failed=true;}if(!failed)throw new AssertionError("Accepted: "+s);}
 if(Validation.warning(1250,1250,50).length()!=0)throw new AssertionError();if(Validation.warning(1850,1250,50).isEmpty())throw new AssertionError();if(Validation.warning(1200,1250,50).isEmpty())throw new AssertionError();System.out.println("15 validation checks passed");
 }
}
