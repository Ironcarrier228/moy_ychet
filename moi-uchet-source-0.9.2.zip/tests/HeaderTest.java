import kz.meter.*;import org.json.*;import java.io.*;
public class HeaderTest {
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 public static void main(String[] a)throws Exception{
 for(String alias:new String[]{"ЕРЦ"," № ЕРЦ ","Номер ЕРЦ:","Лицевой\nсчёт ЕРЦ","ЕРЦ (лицевой счет)","ERC","EРЦ","ЕPЦ","ЕРЦ Астана","ЕРЦ / л.с."})check(Identifiers.header(alias).equals("ЕРЦ"),"alias: "+alias);
 check(!Identifiers.header("Лицевой счёт").equals("ЕРЦ"),"ambiguous account not guessed");
 JSONArray r=ExcelImport.read(new FileInputStream("meter/tests/fixtures/header-title.xlsx"));check(r.length()==3,"rows after title");check(r.getJSONObject(0).getInt("_headerRow")==5,"header at row 5");check(r.getJSONObject(0).getString("row").equals("6"),"physical row preserved");check(r.getJSONObject(0).getString("ЕРЦ").equals("100001"),"ERC alias");
 for(String name:new String[]{"missing","duplicate","too-late"}){boolean threw=false;try{ExcelImport.read(new FileInputStream("meter/tests/fixtures/header-"+name+".xlsx"));}catch(Exception e){threw=true;if(name.equals("missing")){check(e.getMessage().contains("Прочитано:"),"read headers listed");check(e.getMessage().contains("Лицевой счёт"),"actual title shown");check(e.getMessage().contains("Не хватает: ЕРЦ"),"missing ERC explicit");}if(name.equals("duplicate"))check(e.getMessage().contains("несколько столбцов"),"ambiguous header rejected");}check(threw,"reject "+name);}
 System.out.println("Excel headers PASS: aliases, title rows, physical row numbers, missing-header diagnostics, no account guessing, duplicate rejection, scan limit");
 }
}
