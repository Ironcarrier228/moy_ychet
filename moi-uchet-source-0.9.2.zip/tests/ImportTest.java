import kz.meter.*;import org.json.*;import java.io.*;
public class ImportTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static JSONArray read(String p)throws Exception{return ExcelImport.read(new FileInputStream(p));}
 static JSONObject state()throws Exception{return new JSONObject("{\"subscribers\":[{\"id\":\"s0\",\"name\":\"Иванов Алексей\",\"erc\":\"100001\",\"active\":true}],\"meters\":[{\"id\":\"m0\",\"subscriber\":\"s0\",\"type\":\"ХВС\",\"number\":\"123450\",\"initial\":1166,\"initialDate\":\"2026-06-01\"}],\"readings\":[],\"settings\":{}}");}
 public static void main(String[] args)throws Exception{
 JSONArray a=read("meter/tests/fixtures/history.xlsx");JSONObject s=state(),p=ExcelImport.plan(a,s);
 check(a.length()==3,"rows");check(a.getJSONObject(0).getString("Дата").equals("2026-06-25"),"Excel date");check(p.getInt("ready")==3&&p.getInt("errors")==0,"valid history");
 s.put("readings",p.getJSONArray("inserts"));p=ExcelImport.plan(a,s);check(p.getInt("skipped")==3&&p.getInt("ready")==0,"idempotence");
 JSONArray conflict=new JSONArray(a.toString());conflict.getJSONObject(2).put("Новое показание","1251");p=ExcelImport.plan(conflict,s);check(p.getInt("errors")==1,"conflict");check(s.getJSONArray("readings").getJSONObject(2).getLong("value")==1250,"immutable");
 p=ExcelImport.plan(read("meter/tests/fixtures/formula.xlsx"),state());check(p.getInt("errors")>0,"formula rejection");
 p=ExcelImport.plan(read("meter/tests/fixtures/shared.xlsx"),state());check(p.getInt("ready")==1&&p.getJSONArray("inserts").getJSONObject(0).getLong("value")==1250,"shared strings and decimals");
 JSONArray bad=new JSONArray(a.toString());bad.getJSONObject(0).put("№ прибора","unknown");check(ExcelImport.plan(bad,state()).getInt("errors")>0,"unknown meter");
 bad=new JSONArray(a.toString());bad.getJSONObject(0).put("Дата",java.time.LocalDate.now().toString());check(ExcelImport.plan(bad,state()).getInt("errors")>0,"current month blocked");
 bad=new JSONArray(a.toString());bad.getJSONObject(1).put("Предыдущее показание","1");check(ExcelImport.plan(bad,state()).getInt("errors")>0,"chain mismatch");
 bad=new JSONArray(a.toString());bad.put(a.getJSONObject(0));check(ExcelImport.plan(bad,state()).getInt("skipped")==1,"duplicate within file");
 JSONObject existing=new JSONObject("{\"id\":\"old\",\"meter\":\"m0\",\"date\":\"2026-09-01\",\"value\":1280,\"previous\":1240,\"usage\":40}");s=state();s.getJSONArray("readings").put(existing);p=ExcelImport.plan(a,s);check(p.getInt("warnings")>0&&existing.getInt("usage")==40,"successor not rewritten");
 bad=new JSONArray(a.toString());bad.getJSONObject(0).put("Новое показание","1e3");check(ExcelImport.plan(bad,state()).getInt("errors")>0,"text numeric rejection");

 for(String erc:new String[]{"100 001","100\u00a0001","100\u202f001","100001.0","00100001","1.00001E+05","'100001","\ufeff100001"}){bad=new JSONArray(a.toString());bad.getJSONObject(0).put("ЕРЦ",erc);p=ExcelImport.plan(bad,state());check(p.getInt("errors")==0&&p.getInt("ready")==3,"ERC format "+erc);check(p.getInt("warnings")>0,"normalization warning "+erc);}
 bad=new JSONArray(a.toString());bad.getJSONObject(0).put("№ прибора","00123450.0").put("Тип прибора"," холодная\u00a0вода ");check(ExcelImport.plan(bad,state()).getInt("errors")==0,"meter and type formats");
 bad=new JSONArray(a.toString());bad.getJSONObject(0).put("№ прибора","missing");check(ExcelImport.plan(bad,state()).getJSONArray("rows").getJSONObject(0).getString("message").contains("ЕРЦ найден, но прибор"),"precise missing meter");
 bad=new JSONArray(a.toString());bad.getJSONObject(0).put("Тип прибора","ГВС");check(ExcelImport.plan(bad,state()).getJSONArray("rows").getJSONObject(0).getString("message").contains("ЕРЦ и номер прибора найдены"),"precise type error");
 bad=new JSONArray(a.toString());bad.getJSONObject(0).put("ЕРЦ","unknown");check(ExcelImport.plan(bad,state()).getJSONArray("rows").getJSONObject(0).getString("message").contains("не найден"),"precise ERC error");
 s=state();s.getJSONArray("subscribers").put(new JSONObject("{\"id\":\"s1\",\"name\":\"Duplicate\",\"erc\":\"00100001\"}"));s.getJSONArray("meters").put(new JSONObject("{\"id\":\"m1\",\"subscriber\":\"s1\",\"type\":\"ХВС\",\"number\":\"123450\"}"));check(ExcelImport.plan(a,s).getInt("errors")==3,"ambiguous formats blocked");
 check(!Identifiers.matches("AB-123","AB123"),"significant punctuation preserved");check(!Identifiers.matches("100001.5","100001"),"fractional ID not truncated");check(Identifiers.header(" № ЕРЦ ").equals("ЕРЦ"),"header alias");
 System.out.println("Import checks PASS: XLSX dates, shared strings, decimals, formulas, duplicates, conflicts, matching, history ordering, current month guard, immutable successor");
 }
}
