package kz.meter;public class TelegramReminderJob {}
