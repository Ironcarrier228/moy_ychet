import kz.meter.*;import org.json.*;import java.util.*;
public class ReadingExtractorTest {
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 static String sample(String value){return "saiman\n\n"+value+"\n\nНомад\nCO-3701\n- kW•h\nA-3200 imp/kW-h\n220 V 5÷60A 50Hz\n侴\nГОСТ 30207-94\nМЭК 1036-96\nТУ 640 РК 3951910 ЗАО-10-2000\nГод вып. 2004 Nº 361129\nBoig\ngor.ka\n0211204";}
 static long suggested(String text)throws Exception{return ReadingExtractor.extract(text).getJSONObject("suggested").getLong("value");}
 public static void main(String[] args)throws Exception {
 JSONObject r=ReadingExtractor.extract(sample("310766"));check(r.getJSONObject("suggested").getLong("value")==310766,"user sample");check(r.getJSONArray("candidates").length()==2,"technical numbers removed");check(r.getBoolean("ambiguous"),"alternative not concealed");check(r.getBoolean("manualRequired"),"review mandatory");
 Random random=new Random(84);for(int i=0;i<1000;i++){long v=100000+random.nextInt(800000);check(suggested(sample(String.valueOf(v)))==v,"not hardcoded: "+v);}
 check(suggested("OtherBrand\n987654\nCO-1234\n9001111")==987654,"no brand dependency");
 check(suggested("Показание: 000987.65\n№ 333444")==987,"label and integer conversion");check(suggested("000123,456")==123,"comma fraction");check(suggested("31 07 66")==310766,"spaced display digits");check(suggested("0000")==0,"zero");
 check(!ReadingExtractor.extract("CO-3701\n220 V 5÷60A 50Hz\nГод вып. 2004 Nº 361129\nГОСТ 30207-94").has("suggested"),"no guess from specifications");
 check(!ReadingExtractor.extract("Серийный номер\n789456").has("suggested"),"serial label on preceding line");check(suggested("№\n789456\nПоказание: 000876")==876,"skip standalone serial with explicit preceding label");check(suggested("876543\nПоказание: 003210")==3210,"label priority");check(suggested("987654\n12345 kW•h")==12345,"reading units priority");
 check(!ReadingExtractor.extract("-42\nabc\n999999999999999999999999").has("suggested"),"negative and overflow rejected");r=ReadingExtractor.extract("001234\n1234");check(r.getJSONArray("candidates").length()==1&&!r.getBoolean("ambiguous"),"equivalent candidates deduplicated");
 System.out.println("ReadingExtractor PASS: supplied text, 1000 varied values, no brand/value binding, filtered specifications, leading zeros/fractions, alternative ambiguity, manual review");
 }
}
