#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
SDK="${ANDROID_HOME:-../.cache/meter-tools/android}"
SDK="$(cd "$SDK" && pwd)"
BT="$SDK/build-tools/33.0.2"
JAR="$SDK/platforms/android-33/android.jar"
mkdir -p build/classes build/dex build/gen signing
"$BT/aapt" package -f -M app/src/main/AndroidManifest.xml -S app/src/main/res -A app/src/main/assets -I "$JAR" -J build/gen -F build/base.apk
javac -encoding UTF-8 --release 8 -classpath "$JAR" -d build/classes app/src/main/java/kz/meter/*.java
"$BT/d8" --lib "$JAR" --min-api 26 --output build/dex $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q -u ../unsigned.apk classes.dex)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
if [ ! -f signing/local.keystore ]; then "$(dirname "$(readlink -f "$(which java)")")/keytool" -genkeypair -keystore signing/local.keystore -storepass android -keypass android -alias local -keyalg RSA -validity 10000 -dname 'CN=Meter Local Development' >/dev/null 2>&1; fi
"$BT/apksigner" sign --ks signing/local.keystore --ks-pass pass:android --key-pass pass:android --out build/moi-uchet.apk build/aligned.apk
"$BT/apksigner" verify --verbose build/moi-uchet.apk
